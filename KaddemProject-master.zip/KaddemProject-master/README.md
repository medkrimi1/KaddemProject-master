# KaddemProject
A student contracts management application. Using spring boot
