package tn.ey.dev.kaddemproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KaddemProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
