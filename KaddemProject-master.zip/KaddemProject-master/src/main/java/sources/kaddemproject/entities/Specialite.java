package tn.ey.dev.kaddemproject.entities;

public enum Specialite {
    IA,
    RESEAUX,
    CLOUD,
    SECURITE;
}
