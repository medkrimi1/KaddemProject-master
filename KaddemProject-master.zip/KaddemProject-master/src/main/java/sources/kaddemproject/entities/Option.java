package tn.ey.dev.kaddemproject.entities;

public enum Option {
    GAMIX,
    SE,
    SIM,
    NIDS;
}
