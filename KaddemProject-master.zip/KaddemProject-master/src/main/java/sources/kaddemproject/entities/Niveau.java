package tn.ey.dev.kaddemproject.entities;

public enum Niveau {
    JUNIOR,
    SENIOR,
    EXPERT;

    }
